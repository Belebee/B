"""
Main arbitrage monitoring logic
"""

import asyncio
import logging
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional

from config import Config
from mexc_api import MEXCAPIClient
from dex_api import DexScreenerAPI
from telegram_bot import TelegramBot


class ArbitrageMonitor:
    """Main arbitrage monitoring class"""

    def __init__(self, config: Config, telegram_bot: TelegramBot):
        self.config = config
        self.telegram_bot = telegram_bot
        self.logger = logging.getLogger(__name__)

        # Statistics
        self.stats = {
            'total_checks': 0,
            'opportunities_found': 0,
            'start_time': datetime.now(),
            'last_check': None,
            'errors': 0
        }

        # Track recent opportunities to avoid spam
        self.recent_opportunities = {}
        self.opportunity_cooldown = 300  # 5 minutes cooldown

        self.running = False
        self.monitor_task = None

    async def start_monitoring(self):
        """Start the arbitrage monitoring process"""
        self.running = True
        self.logger.info(f"🔍 Starting arbitrage monitoring for {len(self.config.target_pairs)} pairs")

        # Start the monitoring loop
        self.monitor_task = asyncio.create_task(self._monitoring_loop())

        # Start status reporting task
        status_task = asyncio.create_task(self._status_reporting_loop())

        await asyncio.gather(self.monitor_task, status_task, return_exceptions=True)

    async def stop_monitoring(self):
        """Stop the arbitrage monitoring process"""
        self.running = False

        if self.monitor_task:
            self.monitor_task.cancel()
            try:
                await self.monitor_task
            except asyncio.CancelledError:
                pass

        self.logger.info("🛑 Arbitrage monitoring stopped")

    async def _monitoring_loop(self):
        """Main monitoring loop"""
        while self.running:
            try:
                await self._check_arbitrage_opportunities()
                self.stats['last_check'] = datetime.now()

                # Wait for next check
                await asyncio.sleep(self.config.check_interval)

            except asyncio.CancelledError:
                break
            except Exception as e:
                self.logger.error(f"💥 Error in monitoring loop: {e}")
                self.stats['errors'] += 1

                # Send error alert if too many errors
                if self.stats['errors'] % 10 == 0:
                    await self.telegram_bot.send_error_alert("Monitoring Loop", str(e))

                await asyncio.sleep(30)  # Wait 30 seconds before retrying

    async def _status_reporting_loop(self):
        """Send periodic status updates"""
        while self.running:
            try:
                # Send status update every hour
                await asyncio.sleep(3600)

                if self.running:
                    uptime = datetime.now() - self.stats['start_time']
                    status = {
                        'active_pairs': len(self.config.target_pairs),
                        'total_checks': self.stats['total_checks'],
                        'opportunities_found': self.stats['opportunities_found'],
                        'uptime': str(uptime).split('.')[0]  # Remove microseconds
                    }

                    await self.telegram_bot.send_status_update(status)

            except asyncio.CancelledError:
                break
            except Exception as e:
                self.logger.error(f"Error in status reporting: {e}")

    async def _check_arbitrage_opportunities(self):
        """Check for arbitrage opportunities across all target pairs"""
        try:
            self.logger.info(f"🔄 Checking {len(self.config.target_pairs)} pairs for arbitrage opportunities...")

            async with MEXCAPIClient(self.config.mexc_api_key, self.config.mexc_secret_key) as mexc_client:
                async with DexScreenerAPI() as dex_client:

                    # Process pairs in batches to avoid rate limits
                    batch_size = 5
                    for i in range(0, len(self.config.target_pairs), batch_size):
                        batch = self.config.target_pairs[i:i + batch_size]
                        await self._process_pair_batch(batch, mexc_client, dex_client)

                        # Small delay between batches
                        if i + batch_size < len(self.config.target_pairs):
                            await asyncio.sleep(2)

            self.stats['total_checks'] += 1

        except Exception as e:
            self.logger.error(f"Error checking arbitrage opportunities: {e}")
            raise

    async def _process_pair_batch(self, pairs: List[str], mexc_client: MEXCAPIClient, dex_client: DexScreenerAPI):
        """Process a batch of pairs concurrently"""
        tasks = []

        for symbol in pairs:
            task = self._check_single_pair(symbol, mexc_client, dex_client)
            tasks.append(task)

        results = await asyncio.gather(*tasks, return_exceptions=True)

        for i, result in enumerate(results):
            if isinstance(result, Exception):
                self.logger.error(f"Error processing {pairs[i]}: {result}")

    async def _check_single_pair(self, symbol: str, mexc_client: MEXCAPIClient, dex_client: DexScreenerAPI):
        """Check arbitrage opportunity for a single trading pair"""
        try:
            # Get MEXC bid/ask prices
            mexc_bid, mexc_ask = await mexc_client.get_best_bid_ask(symbol)
            if mexc_bid is None or mexc_ask is None:
                self.logger.warning(f"⚠️ No MEXC bid/ask prices for {symbol}, skipping to next pair")
                return

            # Get DEX price
            dex_price, liquidity, network, contract = await dex_client.get_best_dex_price(
                symbol, self.config.min_liquidity
            )

            if dex_price is None:
                self.logger.warning(f"⚠️ No DEX price for {symbol}, skipping to next pair")
                return

            # Check deposit/withdrawal status
            deposit_enabled, withdrawal_enabled, withdrawal_fee = await mexc_client.check_deposit_withdrawal_status(symbol)

            # Check both arbitrage directions with appropriate prices

            # Direction 1: DEX to MEXC (buy from DEX, sell on MEXC)
            # Use MEXC bid price (what we can sell for on MEXC)
            dex_to_mexc_diff = ((mexc_bid - dex_price) / dex_price) * 100

            # Filter out extreme price differences
            if abs(dex_to_mexc_diff) <= self.config.max_price_difference:
                await self._evaluate_arbitrage_opportunity(
                    symbol, mexc_bid, dex_price, dex_to_mexc_diff,
                    network, contract, liquidity, deposit_enabled,
                    withdrawal_enabled, withdrawal_fee, 'dex_to_mexc'
                )
            else:
                self.logger.warning(f"⚠️ Extreme price difference for {symbol} (dex_to_mexc): {dex_to_mexc_diff:.2f}%, skipping")

            # Direction 2: MEXC to DEX (buy from MEXC, sell on DEX)  
            # Use MEXC ask price (what we need to pay to buy on MEXC)
            mexc_to_dex_diff = ((dex_price - mexc_ask) / mexc_ask) * 100

            # Filter out extreme price differences
            if abs(mexc_to_dex_diff) <= self.config.max_price_difference:
                await self._evaluate_arbitrage_opportunity(
                    symbol, mexc_ask, dex_price, mexc_to_dex_diff,
                    network, contract, liquidity, deposit_enabled,
                    withdrawal_enabled, withdrawal_fee, 'mexc_to_dex'
                )
            else:
                self.logger.warning(f"⚠️ Extreme price difference for {symbol} (mexc_to_dex): {mexc_to_dex_diff:.2f}%, skipping")

        except Exception as e:
            self.logger.error(f"❌ Error checking {symbol}: {e}, skipping to next pair")
            # Don't raise the exception, just log it and continue

    async def _evaluate_arbitrage_opportunity(self, symbol: str, mexc_price: float, dex_price: float,
                                           price_diff_percent: float, network: str, contract: str,
                                           liquidity: float, deposit_enabled: bool,
                                           withdrawal_enabled: bool, withdrawal_fee: float, direction: str):
        """Evaluate if an arbitrage opportunity meets the criteria"""
        try:
            opportunity = None

            # Calculate withdrawal fee percentage
            withdrawal_fee_percent = (withdrawal_fee / mexc_price * 100) if mexc_price > 0 else 0

            if direction == 'dex_to_mexc':
                # DEX to MEXC arbitrage (buy from DEX, sell on MEXC using bid price)
                if (price_diff_percent >= self.config.min_profit_threshold and 
                    deposit_enabled and 
                    liquidity >= self.config.min_liquidity):

                    opportunity = {
                        'symbol': symbol,
                        'direction': 'dex_to_mexc',
                        'mexc_price': mexc_price,  # This is the bid price
                        'dex_price': dex_price,
                        'profit_percent': price_diff_percent,
                        'network': network,
                        'contract': contract,
                        'liquidity': liquidity,
                        'deposit_enabled': deposit_enabled,
                        'withdrawal_enabled': withdrawal_enabled,
                        'withdrawal_fee': withdrawal_fee,
                        'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S UTC'),
                        'mexc_url': self.config.get_mexc_url(symbol),
                        'dex_url': self.config.get_dex_url(network, contract)
                    }

            elif direction == 'mexc_to_dex':
                # MEXC to DEX arbitrage (buy from MEXC using ask price, sell on DEX)
                if (price_diff_percent >= self.config.min_profit_threshold and 
                    withdrawal_enabled and 
                    withdrawal_fee_percent <= self.config.max_withdrawal_fee_percent and
                    liquidity >= self.config.min_liquidity):

                    # Adjust profit calculation for withdrawal fees
                    adjusted_profit = price_diff_percent - withdrawal_fee_percent

                    if adjusted_profit >= self.config.min_profit_threshold:
                        opportunity = {
                            'symbol': symbol,
                            'direction': 'mexc_to_dex',
                            'mexc_price': mexc_price,  # This is the ask price
                            'dex_price': dex_price,
                            'profit_percent': adjusted_profit,
                            'network': network,
                            'contract': contract,
                            'liquidity': liquidity,
                            'deposit_enabled': deposit_enabled,
                            'withdrawal_enabled': withdrawal_enabled,
                            'withdrawal_fee': withdrawal_fee,
                            'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S UTC'),
                            'mexc_url': self.config.get_mexc_url(symbol),
                            'dex_url': self.config.get_dex_url(network, contract)
                        }

            # Send notification if opportunity found
            if opportunity:
                if self._should_send_notification(symbol, opportunity['direction']):
                    self.logger.info(f"💡 Arbitrage opportunity found: {symbol} ({opportunity['direction']}) - {opportunity['profit_percent']:.2f}%")

                    success = await self.telegram_bot.send_arbitrage_opportunity(opportunity)

                    if success:
                        self.stats['opportunities_found'] += 1
                        self._record_opportunity(symbol, opportunity['direction'])
                    else:
                        self.logger.error(f"Failed to send notification for {symbol}")
                else:
                    self.logger.debug(f"Skipping notification for {symbol} due to cooldown")

        except Exception as e:
            self.logger.error(f"Error evaluating opportunity for {symbol}: {e}")

    def _should_send_notification(self, symbol: str, direction: str) -> bool:
        """Check if we should send a notification (avoid spam)"""
        key = f"{symbol}_{direction}"
        now = datetime.now()

        if key in self.recent_opportunities:
            last_sent = self.recent_opportunities[key]
            if (now - last_sent).total_seconds() < self.opportunity_cooldown:
                return False

        return True

    def _record_opportunity(self, symbol: str, direction: str):
        """Record that we sent a notification for this opportunity"""
        key = f"{symbol}_{direction}"
        self.recent_opportunities[key] = datetime.now()

        # Clean up old entries
        cutoff = datetime.now() - timedelta(seconds=self.opportunity_cooldown * 2)
        self.recent_opportunities = {
            k: v for k, v in self.recent_opportunities.items() 
            if v > cutoff
        }