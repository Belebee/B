"""
MEXC Exchange API client using CCXT for fetching market data
"""

import ccxt
import asyncio
import logging
from typing import Dict, Any, Optional, Tuple

from utils import retry_on_failure


class MEXCAPIClient:
    """MEXC API client using CCXT for interacting with exchange data"""

    def __init__(self, api_key: str, secret_key: str):
        self.api_key = api_key
        self.secret_key = secret_key
        self.logger = logging.getLogger(__name__)

        # Initialize CCXT MEXC exchange
        self.exchange = ccxt.mexc({
            'apiKey': api_key,
            'secret': secret_key,
            'sandbox': False,  # Use live trading
            'enableRateLimit': True,
            'options': {
                'defaultType': 'spot'  # Use spot trading
            }
        })

    async def __aenter__(self):
        """Async context manager entry"""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit"""
        if hasattr(self.exchange, 'close'):
            await self.exchange.close()

    @retry_on_failure(max_retries=3, delay=1)
    async def get_ticker_price(self, symbol: str) -> Optional[float]:
        """Get current ticker price for a symbol using CCXT"""
        try:
            # Convert symbol format (e.g., BROCKUSDT -> BROCK/USDT)
            ccxt_symbol = self._convert_symbol_format(symbol)

            # Get ticker data
            ticker = await asyncio.get_event_loop().run_in_executor(
                None, self.exchange.fetch_ticker, ccxt_symbol
            )

            if ticker and 'last' in ticker and ticker['last']:
                price = float(ticker['last'])
                if price > 0:
                    self.logger.debug(f"MEXC price for {symbol}: ${price}")
                    return price
                else:
                    self.logger.warning(f"Invalid price (${price}) for {symbol}")

            self.logger.warning(f"No valid price data for {symbol}")
            return None

        except ccxt.BaseError as e:
            if 'Invalid symbol' in str(e) or 'symbol not found' in str(e).lower():
                self.logger.warning(f"Invalid symbol for MEXC: {symbol}")
                return None
            else:
                self.logger.error(f"CCXT error for {symbol}: {e}")
                raise
        except Exception as e:
            self.logger.error(f"Failed to get ticker price for {symbol}: {e}")
            raise

    @retry_on_failure(max_retries=3, delay=1)
    async def get_best_bid_ask(self, symbol: str) -> Tuple[Optional[float], Optional[float]]:
        """
        Get best bid and ask prices for a symbol using CCXT
        Returns: (best_bid, best_ask)
        """
        try:
            # Convert symbol format (e.g., BROCKUSDT -> BROCK/USDT)
            ccxt_symbol = self._convert_symbol_format(symbol)

            # Get order book data
            order_book = await asyncio.get_event_loop().run_in_executor(
                None, self.exchange.fetch_order_book, ccxt_symbol, 5
            )

            if not order_book:
                return None, None

            best_bid = None
            best_ask = None

            # Get best bid (highest buy price)
            if 'bids' in order_book and order_book['bids'] and len(order_book['bids']) > 0:
                best_bid = float(order_book['bids'][0][0])

            # Get best ask (lowest sell price)  
            if 'asks' in order_book and order_book['asks'] and len(order_book['asks']) > 0:
                best_ask = float(order_book['asks'][0][0])

            self.logger.debug(f"MEXC best bid/ask for {symbol}: bid=${best_bid}, ask=${best_ask}")
            return best_bid, best_ask

        except ccxt.BaseError as e:
            if 'Invalid symbol' in str(e) or 'symbol not found' in str(e).lower():
                self.logger.warning(f"Invalid symbol for MEXC: {symbol}")
                return None, None
            else:
                self.logger.error(f"CCXT error for {symbol}: {e}")
                return None, None
        except Exception as e:
            self.logger.error(f"Failed to get best bid/ask for {symbol}: {e}")
            return None, None

    def _convert_symbol_format(self, symbol: str) -> str:
        """
        Convert symbol format from MEXC format to CCXT format
        e.g., BROCKUSDT -> BROCK/USDT
        """
        # Handle common quote currencies
        if symbol.endswith('USDT'):
            base = symbol[:-4]
            return f"{base}/USDT"
        elif symbol.endswith('BUSD'):
            base = symbol[:-4]
            return f"{base}/BUSD"
        elif symbol.endswith('BTC'):
            base = symbol[:-3]
            return f"{base}/BTC"
        elif symbol.endswith('ETH'):
            base = symbol[:-3]
            return f"{base}/ETH"
        else:
            # If no common pattern found, assume USDT
            return f"{symbol}/USDT"

    async def check_deposit_withdrawal_status(self, symbol: str) -> Tuple[bool, bool, float]:
        """
        Check deposit and withdrawal status for a symbol
        Returns: (deposit_enabled, withdrawal_enabled, withdrawal_fee)
        """
        try:
            # Extract base asset from symbol (e.g., 'BROCK' from 'BROCKUSDT')
            base_asset = symbol.replace('USDT', '').replace('BUSD', '').replace('BTC', '').replace('ETH', '')

            # Get currencies info from CCXT
            currencies = await asyncio.get_event_loop().run_in_executor(
                None, self.exchange.fetch_currencies
            )

            deposit_enabled = False
            withdrawal_enabled = False
            withdrawal_fee = 0.0

            if base_asset in currencies:
                currency_info = currencies[base_asset]

                # Check deposit/withdrawal status
                deposit_enabled = currency_info.get('deposit', False)
                withdrawal_enabled = currency_info.get('withdraw', False)

                # Get withdrawal fee
                if 'fee' in currency_info and currency_info['fee']:
                    withdrawal_fee = float(currency_info['fee'])

            return deposit_enabled, withdrawal_enabled, withdrawal_fee

        except Exception as e:
            self.logger.error(f"Failed to check deposit/withdrawal status for {symbol}: {e}")
            return False, False, 0.0

    @retry_on_failure(max_retries=3, delay=1)
    async def get_symbol_info(self, symbol: str) -> Dict[str, Any]:
        """Get symbol information including status and filters"""
        try:
            ccxt_symbol = self._convert_symbol_format(symbol)

            # Load markets to get symbol info
            markets = await asyncio.get_event_loop().run_in_executor(
                None, self.exchange.load_markets
            )

            if ccxt_symbol in markets:
                return markets[ccxt_symbol]

            return {}

        except Exception as e:
            self.logger.error(f"Failed to get symbol info for {symbol}: {e}")
            return {}

    async def get_24hr_stats(self, symbol: str) -> Dict[str, Any]:
        """Get 24hr ticker statistics"""
        try:
            ccxt_symbol = self._convert_symbol_format(symbol)

            ticker = await asyncio.get_event_loop().run_in_executor(
                None, self.exchange.fetch_ticker, ccxt_symbol
            )

            return ticker or {}

        except Exception as e:
            self.logger.error(f"Failed to get 24hr stats for {symbol}: {e}")
            return {}