"""
DEX API client for fetching decentralized exchange data via DexScreener
"""

import asyncio
import aiohttp
import logging
from typing import Dict, Any, Optional, List, Tuple

from utils import retry_on_failure


class DexScreenerAPI:
    """DexScreener API client for DEX data aggregation"""
    
    def __init__(self):
        self.base_url = "https://api.dexscreener.com/latest"
        self.session = None
        self.logger = logging.getLogger(__name__)
    
    async def __aenter__(self):
        """Async context manager entry"""
        self.session = aiohttp.ClientSession()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit"""
        if self.session:
            await self.session.close()
    
    @retry_on_failure(max_retries=3, delay=1)
    async def search_pairs(self, query: str) -> List[Dict[str, Any]]:
        """Search for trading pairs by token name or symbol"""
        if not self.session:
            self.session = aiohttp.ClientSession()
        
        try:
            url = f"{self.base_url}/dex/search/"
            params = {'q': query}
            
            async with self.session.get(url, params=params, timeout=30) as response:
                if response.status == 200:
                    data = await response.json()
                    return data.get('pairs', [])
                else:
                    self.logger.error(f"DexScreener search failed: {response.status}")
                    return []
                    
        except Exception as e:
            self.logger.error(f"Failed to search pairs for {query}: {e}")
            return []
    
    @retry_on_failure(max_retries=3, delay=1)
    async def get_pair_data(self, chain_id: str, pair_address: str) -> Optional[Dict[str, Any]]:
        """Get detailed pair data for a specific chain and pair address"""
        if not self.session:
            self.session = aiohttp.ClientSession()
        
        try:
            url = f"{self.base_url}/dex/pairs/{chain_id}/{pair_address}"
            
            async with self.session.get(url, timeout=30) as response:
                if response.status == 200:
                    data = await response.json()
                    pairs = data.get('pairs', [])
                    return pairs[0] if pairs else None
                else:
                    self.logger.error(f"DexScreener pair data failed: {response.status}")
                    return None
                    
        except Exception as e:
            self.logger.error(f"Failed to get pair data for {chain_id}/{pair_address}: {e}")
            return None
    
    @retry_on_failure(max_retries=3, delay=1)
    async def get_token_pairs(self, token_address: str) -> List[Dict[str, Any]]:
        """Get all pairs for a specific token address"""
        if not self.session:
            self.session = aiohttp.ClientSession()
        
        try:
            url = f"{self.base_url}/dex/tokens/{token_address}"
            
            async with self.session.get(url, timeout=30) as response:
                if response.status == 200:
                    data = await response.json()
                    return data.get('pairs', [])
                else:
                    self.logger.error(f"DexScreener token pairs failed: {response.status}")
                    return []
                    
        except Exception as e:
            self.logger.error(f"Failed to get token pairs for {token_address}: {e}")
            return []
    
    def _filter_pairs_by_liquidity(self, pairs: List[Dict[str, Any]], min_liquidity: float) -> List[Dict[str, Any]]:
        """Filter pairs by minimum liquidity requirement"""
        filtered_pairs = []
        
        for pair in pairs:
            liquidity = pair.get('liquidity', {}).get('usd', 0)
            if liquidity >= min_liquidity:
                filtered_pairs.append(pair)
        
        return filtered_pairs
    
    def _get_best_price_from_pairs(self, pairs: List[Dict[str, Any]]) -> Tuple[Optional[float], float, Dict[str, Any]]:
        """
        Get the best price from a list of pairs
        Returns: (price, liquidity, best_pair_info)
        """
        if not pairs:
            return None, 0.0, {}
        
        best_pair = None
        best_price = None
        highest_liquidity = 0
        
        for pair in pairs:
            price = pair.get('priceUsd')
            liquidity = pair.get('liquidity', {}).get('usd', 0)
            
            if price and liquidity > highest_liquidity:
                best_price = float(price)
                highest_liquidity = liquidity
                best_pair = pair
        
        return best_price, highest_liquidity, best_pair or {}
    
    async def get_best_dex_price(self, symbol: str, min_liquidity: float = 100) -> Tuple[Optional[float], float, str, str]:
        """
        Get the best DEX price for a symbol across all supported networks
        Returns: (price, liquidity, network, contract_address)
        """
        try:
            # Remove USDT suffix to get base token symbol
            base_symbol = symbol.replace('USDT', '').replace('BUSD', '').replace('BTC', '').replace('ETH', '')
            
            # Search for pairs
            pairs = await self.search_pairs(base_symbol)
            
            if not pairs:
                self.logger.warning(f"No pairs found for {base_symbol}")
                return None, 0.0, "", ""
            
            # Filter by liquidity
            filtered_pairs = self._filter_pairs_by_liquidity(pairs, min_liquidity)
            
            if not filtered_pairs:
                self.logger.warning(f"No pairs with sufficient liquidity for {base_symbol}")
                return None, 0.0, "", ""
            
            # Get best price
            best_price, liquidity, best_pair = self._get_best_price_from_pairs(filtered_pairs)
            
            if best_price is None:
                return None, 0.0, "", ""
            
            # Extract network and contract information
            chain_id = best_pair.get('chainId', '')
            base_token = best_pair.get('baseToken', {})
            contract_address = base_token.get('address', '')
            
            # Map chain ID to network name
            chain_map = {
                'ethereum': 'ethereum',
                'bsc': 'bsc',
                'polygon': 'polygon',
                'avalanche': 'avalanche',
                'arbitrum': 'arbitrum',
                'optimism': 'optimism',
                'fantom': 'fantom',
                'solana': 'solana'
            }
            
            network = chain_map.get(chain_id, chain_id)
            
            self.logger.info(f"Best DEX price for {symbol}: ${best_price:.6f} on {network} (Liquidity: ${liquidity:.2f})")
            
            return best_price, liquidity, network, contract_address
            
        except Exception as e:
            self.logger.error(f"Failed to get best DEX price for {symbol}: {e}")
            return None, 0.0, "", ""
    
    async def get_multiple_token_prices(self, symbols: List[str], min_liquidity: float = 100) -> Dict[str, Tuple[Optional[float], float, str, str]]:
        """Get DEX prices for multiple tokens concurrently"""
        tasks = []
        
        for symbol in symbols:
            task = self.get_best_dex_price(symbol, min_liquidity)
            tasks.append(task)
        
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        token_prices = {}
        for i, result in enumerate(results):
            symbol = symbols[i]
            if isinstance(result, Exception):
                self.logger.error(f"Failed to get price for {symbol}: {result}")
                token_prices[symbol] = (None, 0.0, "", "")
            else:
                token_prices[symbol] = result
        
        return token_prices
