"""
Telegram bot for sending arbitrage opportunity notifications
"""

import asyncio
import logging
import aiohttp
from typing import Dict, Any

from config import Config


class TelegramBot:
    """Telegram bot for sending notifications"""
    
    def __init__(self, config: Config):
        self.config = config
        self.bot_token = config.telegram_bot_token
        self.base_url = f"https://api.telegram.org/bot{self.bot_token}"
        self.session = None
        self.logger = logging.getLogger(__name__)
    
    async def initialize(self):
        """Initialize the Telegram bot"""
        try:
            self.session = aiohttp.ClientSession()
            
            # Test bot connection
            response = await self._make_request("getMe")
            if response and response.get("ok"):
                username = response.get("result", {}).get("username", "Unknown")
                self.logger.info(f"✅ Telegram bot initialized: @{username}")
                
                # Send startup message
                await self.send_message("🤖 بوت مراقبة المراجحة بدأ العمل\nArbitrage monitoring bot started")
            else:
                raise Exception("Failed to connect to Telegram API")
            
        except Exception as e:
            self.logger.error(f"❌ Failed to initialize Telegram bot: {e}")
            raise
    
    async def stop(self):
        """Stop the Telegram bot"""
        try:
            await self.send_message("🛑 بوت مراقبة المراجحة توقف\nArbitrage monitoring bot stopped")
            if self.session:
                await self.session.close()
        except Exception as e:
            self.logger.error(f"Error sending stop message: {e}")
    
    async def _make_request(self, method: str, params: dict = None) -> dict:
        """Make a request to Telegram API"""
        if not self.session:
            self.session = aiohttp.ClientSession()
        
        url = f"{self.base_url}/{method}"
        request_params = params if params is not None else {}
        
        try:
            async with self.session.post(url, json=request_params) as response:
                return await response.json()
        except Exception as e:
            self.logger.error(f"Telegram API request failed: {e}")
            return {}
    
    async def send_message(self, text: str) -> bool:
        """Send a message to the admin"""
        try:
            params = {
                "chat_id": self.config.admin_id,
                "text": text,
                "parse_mode": "HTML",
                "disable_web_page_preview": True
            }
            
            response = await self._make_request("sendMessage", params)
            
            if response.get("ok"):
                return True
            else:
                self.logger.error(f"Failed to send message: {response}")
                return False
            
        except Exception as e:
            self.logger.error(f"Failed to send Telegram message: {e}")
            return False
    
    def _format_arbitrage_message(self, opportunity: Dict[str, Any]) -> str:
        """Format arbitrage opportunity message in Arabic and English"""
        symbol = opportunity.get('symbol', 'N/A')
        direction = opportunity.get('direction', 'unknown')
        mexc_price = opportunity.get('mexc_price', 0)
        dex_price = opportunity.get('dex_price', 0)
        profit_percent = opportunity.get('profit_percent', 0)
        network = opportunity.get('network', 'N/A')
        liquidity = opportunity.get('liquidity', 0)
        mexc_url = opportunity.get('mexc_url', '')
        dex_url = opportunity.get('dex_url', '')
        deposit_enabled = opportunity.get('deposit_enabled', False)
        withdrawal_enabled = opportunity.get('withdrawal_enabled', False)
        withdrawal_fee = opportunity.get('withdrawal_fee', 0)
        
        # Determine emoji and direction text
        if direction == 'dex_to_mexc':
            emoji = "📈"
            direction_ar = "شراء من DEX ← بيع على MEXC"
            direction_en = "Buy from DEX → Sell on MEXC"
            action_ar = "اشتري من"
            action_en = "Buy from"
            platform1 = f"DEX ({network})"
            platform2 = "MEXC"
            price1 = dex_price
            price2 = mexc_price
        else:
            emoji = "📉"
            direction_ar = "شراء من MEXC ← بيع على DEX"
            direction_en = "Buy from MEXC → Sell on DEX"
            action_ar = "اشتري من"
            action_en = "Buy from"
            platform1 = "MEXC"
            platform2 = f"DEX ({network})"
            price1 = mexc_price
            price2 = dex_price
        
        # Status indicators
        deposit_status = "✅" if deposit_enabled else "❌"
        withdrawal_status = "✅" if withdrawal_enabled else "❌"
        
        message = f"""
{emoji} <b>فرصة مراجحة / Arbitrage Opportunity</b>

🪙 <b>العملة / Token:</b> {symbol}
🌐 <b>الشبكة / Network:</b> {network}

📊 <b>التوجه / Direction:</b>
{direction_ar}
{direction_en}

💰 <b>الأسعار / Prices:</b>
• {platform1}: ${price1:.6f}
• {platform2}: ${price2:.6f}

📈 <b>نسبة الربح / Profit:</b> {profit_percent:.2f}%

💧 <b>السيولة / Liquidity:</b> ${liquidity:,.2f}

🏦 <b>حالة الخدمات / Service Status:</b>
• الإيداع / Deposit: {deposit_status}
• السحب / Withdrawal: {withdrawal_status}
• رسوم السحب / Withdrawal Fee: ${withdrawal_fee:.6f}

🔗 <b>روابط التداول / Trading Links:</b>
"""
        
        if mexc_url:
            message += f"• <a href='{mexc_url}'>MEXC</a>\n"
        
        if dex_url:
            message += f"• <a href='{dex_url}'>DEX ({network})</a>\n"
        
        message += f"\n⏰ <b>Time:</b> {opportunity.get('timestamp', 'N/A')}"
        
        return message
    
    async def send_arbitrage_opportunity(self, opportunity: Dict[str, Any]) -> bool:
        """Send arbitrage opportunity notification"""
        try:
            message = self._format_arbitrage_message(opportunity)
            return await self.send_message(message)
            
        except Exception as e:
            self.logger.error(f"Failed to send arbitrage opportunity: {e}")
            return False
    
    async def send_error_alert(self, error_type: str, error_message: str) -> bool:
        """Send error alert to admin"""
        message = f"""
⚠️ <b>تنبيه خطأ / Error Alert</b>

🔍 <b>نوع الخطأ / Error Type:</b> {error_type}
📝 <b>الرسالة / Message:</b> {error_message}

🔧 يرجى التحقق من إعدادات البوت
Please check bot configuration
"""
        return await self.send_message(message)
    
    async def send_status_update(self, status: Dict[str, Any]) -> bool:
        """Send periodic status update"""
        active_pairs = status.get('active_pairs', 0)
        total_checks = status.get('total_checks', 0)
        opportunities_found = status.get('opportunities_found', 0)
        uptime = status.get('uptime', 'N/A')
        
        message = f"""
📊 <b>تحديث حالة البوت / Bot Status Update</b>

🔄 <b>الأزواج النشطة / Active Pairs:</b> {active_pairs}
🔍 <b>إجمالي الفحوصات / Total Checks:</b> {total_checks}
💡 <b>الفرص المكتشفة / Opportunities Found:</b> {opportunities_found}
⏱️ <b>وقت التشغيل / Uptime:</b> {uptime}

✅ البوت يعمل بشكل طبيعي / Bot is running normally
"""
        return await self.send_message(message)
