"""
Utility functions for the arbitrage bot
"""

import asyncio
import functools
import logging
from typing import Callable, Any


def retry_on_failure(max_retries: int = 3, delay: float = 1.0, backoff: float = 2.0):
    """
    Decorator for retrying functions on failure with exponential backoff
    
    Args:
        max_retries: Maximum number of retry attempts
        delay: Initial delay between retries (seconds)
        backoff: Multiplier for delay after each failure
    """
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        async def wrapper(*args, **kwargs) -> Any:
            logger = logging.getLogger(func.__module__)
            current_delay = delay
            
            for attempt in range(max_retries + 1):
                try:
                    return await func(*args, **kwargs)
                except Exception as e:
                    if attempt == max_retries:
                        logger.error(f"Function {func.__name__} failed after {max_retries} retries: {e}")
                        raise
                    
                    logger.warning(f"Attempt {attempt + 1} failed for {func.__name__}: {e}. Retrying in {current_delay:.1f}s...")
                    await asyncio.sleep(current_delay)
                    current_delay *= backoff
            
            return None  # Should never reach here
        
        return wrapper
    return decorator


import asyncio
from typing import Any

def validate_price_data(price: Any) -> bool:
    """Validate price data"""
    try:
        if price is None:
            return False
        
        price_float = float(price)
        
        # Check for reasonable price range (not negative, not extremely large)
        if price_float <= 0 or price_float > 1e10:
            return False
        
        return True
        
    except (ValueError, TypeError):
        return False


def calculate_percentage_difference(price1: float, price2: float) -> float:
    """
    Calculate percentage difference between two prices
    Returns: (price1 - price2) / price2 * 100
    """
    if price2 == 0:
        return 0.0
    
    return ((price1 - price2) / price2) * 100


def format_currency(amount: float, decimals: int = 6) -> str:
    """Format currency amount with specified decimal places"""
    return f"${amount:,.{decimals}f}"


def format_percentage(percentage: float, decimals: int = 2) -> str:
    """Format percentage with specified decimal places"""
    return f"{percentage:.{decimals}f}%"


def extract_base_asset(symbol: str) -> str:
    """
    Extract base asset from trading pair symbol
    Examples: BROCKUSDT -> BROCK, BNTUSDT -> BNT
    """
    # Common quote assets to remove
    quote_assets = ['USDT', 'BUSD', 'BTC', 'ETH', 'BNB', 'USDC']
    
    symbol_upper = symbol.upper()
    
    for quote in quote_assets:
        if symbol_upper.endswith(quote):
            return symbol_upper[:-len(quote)]
    
    return symbol_upper


def is_valid_network(network: str, supported_networks: dict) -> bool:
    """Check if network is supported"""
    return network.lower() in [v.lower() for v in supported_networks.values()]


def sanitize_contract_address(address: str) -> str:
    """Sanitize contract address for URL usage"""
    if not address:
        return ""
    
    # Remove any whitespace and ensure proper format
    return address.strip()


def get_network_display_name(network_key: str, supported_networks: dict) -> str:
    """Get display name for network"""
    for display_name, key in supported_networks.items():
        if key == network_key:
            return display_name
    
    return network_key.capitalize()


import asyncio
import time
import functools
from typing import Any, Callable

def retry_on_failure(max_retries: int = 3, delay: float = 1):
    """Decorator to retry async functions on failure"""
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        async def wrapper(*args, **kwargs):
            last_exception = None
            
            for attempt in range(max_retries + 1):
                try:
                    return await func(*args, **kwargs)
                except Exception as e:
                    last_exception = e
                    if attempt < max_retries:
                        await asyncio.sleep(delay * (attempt + 1))  # Exponential backoff
                    else:
                        raise last_exception
            
        return wrapper
    return decorator


class RateLimiter:
    """Simple rate limiter for API requests"""
    
    def __init__(self, max_requests: int, time_window: float):
        """
        Initialize rate limiter
        
        Args:
            max_requests: Maximum number of requests allowed
            time_window: Time window in seconds
        """
        self.max_requests = max_requests
        self.time_window = time_window
        self.requests = []
    
    async def acquire(self):
        """Acquire permission to make a request"""
        import time
        
        now = time.time()
        
        # Remove old requests outside the time window
        self.requests = [req_time for req_time in self.requests if now - req_time < self.time_window]
        
        # Check if we can make a request
        if len(self.requests) >= self.max_requests:
            # Calculate wait time
            oldest_request = min(self.requests)
            wait_time = self.time_window - (now - oldest_request)
            
            if wait_time > 0:
                await asyncio.sleep(wait_time)
        
        # Record this request
        self.requests.append(now)


def create_mexc_rate_limiter() -> RateLimiter:
    """Create rate limiter for MEXC API (1200 requests per minute)"""
    return RateLimiter(max_requests=1200, time_window=60)


def create_dexscreener_rate_limiter() -> RateLimiter:
    """Create rate limiter for DexScreener API (300 requests per minute)"""
    return RateLimiter(max_requests=300, time_window=60)
