#!/usr/bin/env python3
"""
Cryptocurrency Arbitrage Monitoring Bot
Main entry point for the application
"""

import asyncio
import logging
import signal
import sys
from datetime import datetime

from config import Config
from arbitrage_monitor import ArbitrageMonitor
from telegram_bot import TelegramBot


def setup_logging():
    """Configure logging for the application"""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler('arbitrage_bot.log'),
            logging.StreamHandler(sys.stdout)
        ]
    )


class ArbitrageBotApp:
    """Main application class for the arbitrage bot"""
    
    def __init__(self):
        self.config = Config()
        self.telegram_bot = TelegramBot(self.config)
        self.monitor = ArbitrageMonitor(self.config, self.telegram_bot)
        self.running = False
        
    async def start(self):
        """Start the arbitrage monitoring bot"""
        try:
            logging.info("🚀 Starting Cryptocurrency Arbitrage Bot...")
            
            # Initialize Telegram bot
            await self.telegram_bot.initialize()
            
            # Start monitoring
            self.running = True
            await self.monitor.start_monitoring()
            
        except Exception as e:
            logging.error(f"❌ Failed to start bot: {e}")
            raise
    
    async def stop(self):
        """Stop the arbitrage monitoring bot"""
        logging.info("🛑 Stopping Cryptocurrency Arbitrage Bot...")
        self.running = False
        
        # Stop monitoring
        await self.monitor.stop_monitoring()
        
        # Stop Telegram bot
        await self.telegram_bot.stop()
        
        logging.info("✅ Bot stopped successfully")
    
    def handle_signal(self, signum, frame):
        """Handle system signals for graceful shutdown"""
        logging.info(f"📶 Received signal {signum}, initiating shutdown...")
        asyncio.create_task(self.stop())


async def main():
    """Main entry point"""
    setup_logging()
    
    app = ArbitrageBotApp()
    
    # Setup signal handlers for graceful shutdown
    signal.signal(signal.SIGINT, app.handle_signal)
    signal.signal(signal.SIGTERM, app.handle_signal)
    
    try:
        await app.start()
        
        # Keep the bot running
        while app.running:
            await asyncio.sleep(1)
            
    except KeyboardInterrupt:
        logging.info("📱 Keyboard interrupt received")
    except Exception as e:
        logging.error(f"💥 Unexpected error: {e}")
    finally:
        if app.running:
            await app.stop()


if __name__ == "__main__":
    asyncio.run(main())
